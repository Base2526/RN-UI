import { TextStyle, ViewStyle } from 'react-native';
declare const _default: (width: number, height: number, backgroundColor: string) => {
    [x: string]: ViewStyle | TextStyle;
};
export default _default;
export declare const simpleStyle: {
    [x: string]: ViewStyle | TextStyle;
};
