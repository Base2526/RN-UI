import ImageViewer from "./image-viewer.component";
import { Props as ImageViewerPropsDefine } from "./image-viewer.type";
export { ImageViewer, ImageViewerPropsDefine };
export default ImageViewer;
