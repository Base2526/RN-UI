"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var image_viewer_component_1 = require("./image-viewer.component");
exports.ImageViewer = image_viewer_component_1.default;
var image_viewer_type_1 = require("./image-viewer.type");
exports.ImageViewerPropsDefine = image_viewer_type_1.Props;
exports.default = image_viewer_component_1.default;
//# sourceMappingURL=index.js.map