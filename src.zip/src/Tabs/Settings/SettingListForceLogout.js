import React from 'react'
import {View, Text} from 'react-native'

export default class SettingListForceLogout extends React.Component{

    render(){
        return(<View><Text>Setting Force Logout Page</Text></View>)
    }
}