import React from 'react'
import {View, Text} from 'react-native'

export default class SettingListHide extends React.Component{

    render(){
        return(<View><Text>Setting Hide Page</Text></View>)
    }
}