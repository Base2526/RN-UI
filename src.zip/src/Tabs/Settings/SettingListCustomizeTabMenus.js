import React from 'react'
import {View, Text} from 'react-native'

export default class SettingListCustomizeTabMenus extends React.Component{

    render(){
        return(<View><Text>Setting Customize Tab Menus Page</Text></View>)
    }
}