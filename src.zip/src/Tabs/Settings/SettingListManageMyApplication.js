import React from 'react'
import {View, Text} from 'react-native'

export default class SettingListManageMyApplication extends React.Component{

    render(){
        return(<View><Text>Setting Manage My Application Page</Text></View>)
    }
}