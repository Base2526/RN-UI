import React, { Component } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';

class CPUDetails extends Component {

    static navigationOptions = {
        title: 'CPUDetails',
    }

    render() {
        return (
            <View style={styles.container}>
                <Text>CPU Details</Text>

            </View>
        );
    }
}



const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: "center",
        alignItems: "center"
    }
})


export default CPUDetails;