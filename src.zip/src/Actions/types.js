// export const EMAIL_CHANGED = 'email_changed'
// export const PASSWORD_CHANGED = 'password_changed'
export const LOGIN_USER_SUCCESS = 'login_user_success'
export const LOGIN_USER_FAIL = 'login_user_fail'
export const LOGIN_USER = 'login_user'

// export const GET_USER_LOGIN = "get_user_login"

// export const LOADING = 'loading'