ApnsPHP reference documentation
================

1. Install doxygen and graphviz
1. `cd Doc/Reference`
1. Run `doxygen`

The html documentation will be generated in `Doc/Reference/html`.
