#!/bin/sh
php -q php-input-filter.php $@
